import { exportAccounts, serialize } from "../core/export.js";
import { getSettings } from "./watch.js";
const DEBOUNCE_MS = 5_000;
let pending = null;
async function doExport(adapter) {
    const settings = await getSettings();
    if (!settings.enabled || !settings.autoExport || !settings.path)
        return;
    const cfg = await exportAccounts(adapter);
    const json = serialize(cfg);
    const api = browser.portableAccountConfig;
    if (!api || typeof api.writeWatchedFile !== "function") {
        // Write path not yet available in the experiment — surface once and
        // stop retrying until the user reconfigures.
        console.warn("[portable-account-config] autoExport: writeWatchedFile not implemented");
        return;
    }
    try {
        await api.writeWatchedFile(settings.path, json);
    }
    catch (e) {
        console.warn("[portable-account-config] autoExport failed:", e);
    }
}
function schedule(adapter) {
    if (pending)
        clearTimeout(pending);
    pending = setTimeout(() => {
        pending = null;
        void doExport(adapter);
    }, DEBOUNCE_MS);
}
export function installAutoExport(adapter) {
    const accounts = browser.accounts;
    if (!accounts)
        return;
    const wire = (evt) => {
        if (evt && typeof evt.addListener === "function") {
            evt.addListener(() => schedule(adapter));
        }
    };
    wire(accounts.onCreated);
    wire(accounts.onUpdated);
    wire(accounts.onDeleted);
}
//# sourceMappingURL=autoExport.js.map