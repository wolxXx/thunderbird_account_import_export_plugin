/**
 * Adapter interface between Thunderbird's runtime API and the portable model.
 *
 * Following §26 of the specification, this is the single stable seam:
 * everything above (export/import logic, UI, tests) depends on this
 * interface, and only the concrete implementation talks to
 * `messenger.accounts` / the WebExtension experiment.
 *
 * Two implementations live side-by-side:
 *  - `WebExtensionThunderbirdAdapter` (src/adapter/webext.ts) — used at
 *    runtime inside Thunderbird.
 *  - `InMemoryThunderbirdAdapter` (src/adapter/memory.ts) — used by unit
 *    tests and for the round-trip invariant test (§23).
 */
export {};
//# sourceMappingURL=thunderbird.js.map