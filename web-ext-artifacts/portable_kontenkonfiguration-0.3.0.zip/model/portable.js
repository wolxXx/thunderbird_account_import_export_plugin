/**
 * Portable Thunderbird Account Configuration — data model (v1).
 *
 * This model is intentionally decoupled from the internal Thunderbird
 * representation. It contains only the semantic properties needed to
 * re-create an equivalent account on any platform.
 *
 * See: Feature Specification §15 and §26 (stable abstraction layer).
 */
export const PORTABLE_FORMAT = "thunderbird-portable-account-config";
export const PORTABLE_VERSION = 1;
//# sourceMappingURL=portable.js.map